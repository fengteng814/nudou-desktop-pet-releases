努豆桌宠 3.73.2.0 Preview
TODO 人工对账回执可关联原任务、去除重复创建行，并在核对可写上下文后解除本地占用。
保留原 UUID、封存请求及 source_acknowledged=false；保留 20 秒 TODO 读取期限。
尚未公开发布，待办公室实际安装验收。
