﻿努豆桌宠 3.79.0.0 Preview
圆盘 → 快记：直接输入，关闭保留草稿，Ctrl+Enter记下。
同一窗口集中管理多条固定便签，展开阅读和编辑；窗口置顶独立控制。
支持Markdown、Ctrl+滚轮字号、图片粘贴与图文导出、搜索和回收站。
快记数据和图片保存在程序目录；复制/备份时请保留 nudou-quick-*.ini 及 quick-note-assets 文件夹。
