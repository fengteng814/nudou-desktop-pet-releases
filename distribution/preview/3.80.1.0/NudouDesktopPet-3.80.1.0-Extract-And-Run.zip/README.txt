﻿努豆桌宠 3.80.1.0 Preview
圆盘 → 快记：直接输入，Ctrl+Enter记下，Esc保存收起；右上角图钉控制窗口置顶。搜索筛选从更多展开。
每条便签可单独换颜色；快记设置可指定新便签默认色。
把折叠便签拖出窗口成为独立桌面便签；同一条记录保持同一标识，关闭独立窗不删除记录。
展开便签底部可选择已有 Obsidian 仓库并发送图文笔记；原快记保留。
备份请保留 nudou-quick-*.ini、quick-note-assets、quick-note-edit-drafts 和 quick-note-conflicts。
