﻿param([switch]$NoUI, [string]$ReportDirectory = $PSScriptRoot)
$ErrorActionPreference = 'Stop'
$lines = New-Object 'System.Collections.Generic.List[string]'
function Note([string]$text) { $lines.Add($text) }
Note '努豆 · 单位 PC 配对前检查'
Note ('时间：' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
Note '只读检查；不会安装、配对、修改网络设置或任务。'
Note ''
try {
    Add-Type -TypeDefinition @'
using System;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
public static class NudouConnectionProbe {
    public static bool Tcp(string host, int port) {
        using(var c = new TcpClient()) {
            try { var a=c.BeginConnect(host,port,null,null); if(!a.AsyncWaitHandle.WaitOne(3000)) return false; c.EndConnect(a); return true; }
            catch { return false; }
        }
    }
    public static string Https(string publicCert) {
        var trusted=new X509Certificate2(publicCert);
        var req=(HttpWebRequest)WebRequest.Create("https://192.168.4.100:8765/v3/task-lists");
        req.Method="GET"; req.Proxy=null; req.AllowAutoRedirect=false; req.Timeout=5000; req.ReadWriteTimeout=5000;
        req.ServerCertificateValidationCallback=(sender,cert,chain,errors)=> {
            if(cert==null || chain==null || (errors & (SslPolicyErrors.RemoteCertificateNameMismatch|SslPolicyErrors.RemoteCertificateNotAvailable))!=0) return false;
            var actual=new X509Certificate2(cert);
            if(actual.GetRawCertDataString()!=trusted.GetRawCertDataString() || DateTime.UtcNow<actual.NotBefore.ToUniversalTime() || DateTime.UtcNow>actual.NotAfter.ToUniversalTime()) return false;
            foreach(var s in chain.ChainStatus) if((s.Status & ~X509ChainStatusFlags.UntrustedRoot)!=0) return false;
            return true;
        };
        try { using(var r=(HttpWebResponse)req.GetResponse()) return "HTTP "+(int)r.StatusCode; }
        catch(WebException e) { if(e.Response!=null) using(var r=(HttpWebResponse)e.Response) return "HTTP "+(int)r.StatusCode; return e.Status.ToString(); }
        finally { trusted.Dispose(); }
    }
}
'@
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Note ('NAS 局域网端口：' + $(if([NudouConnectionProbe]::Tcp('192.168.4.100',8765)){'可达'}else{'不可达'}))
    Note ('NAS Tailscale 端口：' + $(if([NudouConnectionProbe]::Tcp('100.91.131.127',8765)){'可达'}else{'不可达'}))
    $https=[NudouConnectionProbe]::Https((Join-Path $PSScriptRoot 'server.crt'))
    Note ('NAS 证书与服务：' + $https)
    Note '（HTTP 401 表示服务可达、证书通过，此检查未发送任何配对凭据。）'
} catch { Note ('网络检查未完成：' + $_.Exception.GetType().Name) }
Note ''
$client=Join-Path $env:USERPROFILE '.config\nudou-lan\client.json'
$legacy=Join-Path $env:LOCALAPPDATA 'NudouDesktopPet\Lan\pairing.json'
foreach($entry in @(@('专用配置',$client),@('旧版配对',$legacy))) {
    try {
        if(!(Test-Path -LiteralPath $entry[1] -PathType Leaf)) { Note ($entry[0]+'：不存在'); continue }
        if((Get-Item -LiteralPath $entry[1]).Length -gt 131072) { Note ($entry[0]+'：文件过大'); continue }
        $cfg=Get-Content -Raw -LiteralPath $entry[1] -Encoding UTF8 | ConvertFrom-Json
        Note ($entry[0]+'：存在')
        $id=[string]$cfg.device_id
        Note ('设备身份：'+$(if($id -in @('pet-primary','pet-office','screen-home','mobile-node-primary')){$id}else{'其他或缺失'}))
        $url=$(if($entry[0] -eq '专用配置'){$cfg.base_url}else{$cfg.endpoint})
        Note ('地址：'+$(if($url -eq 'https://192.168.4.100:8765'){'NAS 局域网'}else{'其他或缺失'}))
        $enabled=$(if($entry[0] -eq '专用配置'){$cfg.production_enabled}else{$cfg.enabled})
        Note ('启用状态：'+$(if($enabled -eq $true){'已启用'}else{'未启用'}))
        # Credential values and file contents are deliberately never included in the report.
        $cfg=$null
    } catch { Note ($entry[0]+'：无法读取或格式无效') }
}
Note ''
$versions = @()
foreach($p in @((Join-Path $env:LOCALAPPDATA 'Programs\NudouDesktopPet\努豆桌宠.exe'),(Join-Path $env:LOCALAPPDATA 'Programs\NudouDesktopPet\NudouDesktopPet.exe'))) {
    if(Test-Path -LiteralPath $p -PathType Leaf){$versions += (Get-Item -LiteralPath $p).VersionInfo.FileVersion}
}
Note ('已安装版本：'+$(if($versions.Count){($versions | Select-Object -Unique)-join ', '}else{'未在默认目录找到'}))
Note ''
Note '请把以上结果复制回对话，以便生成这台电脑的专用配对配置。'
$report=$lines -join [Environment]::NewLine
[IO.File]::WriteAllText((Join-Path $ReportDirectory 'Connection-result.txt'),$report,[Text.UTF8Encoding]::new($true))
if($NoUI){$report;exit}
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$form=New-Object Windows.Forms.Form
$form.Text='努豆 · 连接检查';$form.Size=New-Object Drawing.Size(610,580);$form.StartPosition='CenterScreen'
$box=New-Object Windows.Forms.TextBox
$box.Multiline=$true;$box.ReadOnly=$true;$box.ScrollBars='Vertical';$box.Dock='Fill';$box.Font=New-Object Drawing.Font('Microsoft YaHei UI',10);$box.Text=$report
$button=New-Object Windows.Forms.Button
$button.Text='复制检查结果';$button.Dock='Bottom';$button.Height=44
$button.Add_Click({[Windows.Forms.Clipboard]::SetText($box.Text);$button.Text='已复制'})
$form.Controls.Add($box);$form.Controls.Add($button)
[void]$form.ShowDialog()
